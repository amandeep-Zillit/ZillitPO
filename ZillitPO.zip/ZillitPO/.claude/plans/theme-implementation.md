# Theme Implementation Plan

## Overview
Add light/dark theme support to the iOS app, matching the web's `ThemeContext.jsx`. Fetch server theme (`GET /api/v2/project/theme`) for primary/accent colors. Store user's light/dark preference locally.

## Architecture

**`ThemeManager`** — singleton `ObservableObject` that holds:
- `isDark: Bool` (persisted in UserDefaults)
- Server-fetched `primaryColor` / `accentColor` hex strings
- Computed `Color` properties for the full palette (light vs dark variants)

**Color extension** — change `static let` → `static var` computed properties that read from `ThemeManager.shared`, so all existing `Color.gold`, `Color.bgBase` etc. automatically become theme-aware with zero changes to existing views.

## Color Palette (from ThemeContext.jsx)

| Token | Light | Dark |
|-------|-------|------|
| gold | #FC9404 | #FC9404 |
| goldDark | #E08600 | #E08600 |
| bgBase | #F8F9FB | #14161B |
| bgRaised | #F3F4F6 | #22262E |
| bgSurface (white) | #FFFFFF | #1A1D23 |
| borderColor | #E2E4E9 | rgba(255,255,255,0.08) |
| borderSubtle | #EDF0F4 | #2A2E38 |
| text (primary) | system | #E5E7EB |
| textMuted | system secondary | #9CA3AF |

## Files to Create

### 1. `Views/Main/ThemeManager.swift` (NEW)
- `class ThemeManager: ObservableObject`
- `@Published var isDark: Bool` (reads/writes UserDefaults key `"app-theme"`)
- `@Published var serverPrimary: String?` / `serverAccent: String?` (hex from API)
- Computed color properties for full palette
- `toggleTheme()` method
- `Color(hex:)` initializer
- `loadServerTheme()` — calls the API

### 2. Update `Views/Main/ContentView.swift`
- Change `Color` extension from `static let` to `static var` reading from `ThemeManager.shared`
- Add `bgSurface` token (used for card/row backgrounds — currently hardcoded `Color.white`)
- Add theme toggle button to the home page

### 3. Update `Network/PORequest.swift`
- Add `case fetchProjectTheme`
- Endpoint: `GET /api/v2/project/theme`

### 4. Update `Network/POCodableTask.swift`
- Add `case fetchProjectTheme((Result<APIResponse<ProjectThemeRaw>?, Error>) -> Void)`

### 5. Update `Models/Models.swift`
- Add `ProjectThemeRaw: Codable` struct with `primary_color: String?`, `accent_color: String?`

### 6. Update `ViewModel/POViewModel.swift`
- Call `ThemeManager.shared.loadServerTheme()` in `init()`

### 7. Update views for dark mode surfaces
- Replace hardcoded `Color.white` backgrounds in ContentView tiles/cards with `Color.bgSurface`
- Apply `.preferredColorScheme(ThemeManager.shared.isDark ? .dark : .light)` on root view so system controls (nav bar, status bar) adapt

## Implementation Order
1. Create ThemeManager + Color(hex:) + ProjectThemeRaw model
2. Add network endpoint (PORequest + POCodableTask)
3. Update Color extension to be dynamic
4. Wire up fetch in POViewModel.init()
5. Add theme toggle UI to ContentView
6. Replace `Color.white` → `Color.bgSurface` in ContentView cards
7. Apply `.preferredColorScheme` on root NavigationView
