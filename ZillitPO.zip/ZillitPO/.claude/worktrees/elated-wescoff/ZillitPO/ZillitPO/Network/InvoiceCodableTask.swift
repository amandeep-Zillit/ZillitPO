//
//  InvoiceCodableTask.swift
//  ZillitPO
//

import Foundation

enum InvoiceCodableTask {
    // MARK: - Invoices (typed responses)
    case fetchInvoices((Result<APIResponse<[InvoiceRaw]>?, Error>) -> Void)
    case createInvoice([String: Any], (Result<Data?, Error>) -> Void)
    case deleteInvoice(String, (Result<Data?, Error>) -> Void)
    case approveInvoice(String, [String: Any], (Result<Data?, Error>) -> Void)
    case rejectInvoice(String, [String: Any], (Result<Data?, Error>) -> Void)

    // MARK: - Upload (multipart — returns extraction data)
    case uploadInvoice(Data, String, String, (Result<APIResponse<InvoiceExtraction>?, Error>) -> Void)
    // params: fileData, fileName, mimeType, completion

    // MARK: - Approval Tiers
    case fetchInvoiceApprovalTiers((Result<APIResponse<[ApprovalTierConfig]>?, Error>) -> Void)

    // MARK: - Settings
    case getSettings((Result<APIResponse<InvoiceSettingsRaw>?, Error>) -> Void)
    case updateSettings([String: Any], (Result<Data?, Error>) -> Void)

    // MARK: - Payment Runs
    case listActiveRuns((Result<APIResponse<[PaymentRunRaw]>?, Error>) -> Void)
    case getActiveRun(String, (Result<APIResponse<PaymentRunDetailRaw>?, Error>) -> Void)
    case approveActiveRun(String, [String: Any], (Result<Data?, Error>) -> Void)
    case rejectActiveRun(String, [String: Any], (Result<Data?, Error>) -> Void)
}

extension InvoiceCodableTask: PODataTaskProtocol {
    var urlDataTask: URLSessionDataTask? {
        switch self {

        // MARK: Invoices
        case .fetchInvoices(let completion):
            guard let req = InvoiceRequest.fetchInvoices.urlRequest else { return nil }
            return APIClient.shared.codableResultTask(with: req, completion: completion)

        case .createInvoice(let body, let completion):
            guard let req = InvoiceRequest.createInvoice(body).urlRequest else { return nil }
            return APIClient.shared.dataResultTask(with: req, completion: completion)

        case .deleteInvoice(let id, let completion):
            guard let req = InvoiceRequest.deleteInvoice(id).urlRequest else { return nil }
            return APIClient.shared.dataResultTask(with: req, completion: completion)

        case .approveInvoice(let id, let body, let completion):
            guard let req = InvoiceRequest.approveInvoice(id, body).urlRequest else { return nil }
            return APIClient.shared.dataResultTask(with: req, completion: completion)

        case .rejectInvoice(let id, let body, let completion):
            guard let req = InvoiceRequest.rejectInvoice(id, body).urlRequest else { return nil }
            return APIClient.shared.dataResultTask(with: req, completion: completion)

        // MARK: Upload (multipart)
        case .uploadInvoice(let fileData, let fileName, let mimeType, let completion):
            guard let req = APIClient.shared.buildMultipartRequest(
                "/api/v2/invoices/upload",
                fileData: fileData,
                fileName: fileName,
                mimeType: mimeType,
                fieldName: "file"
            ) else { return nil }
            return APIClient.shared.codableResultTask(with: req, completion: completion)

        // MARK: Approval Tiers
        case .fetchInvoiceApprovalTiers(let completion):
            guard let req = InvoiceRequest.fetchInvoiceApprovalTiers.urlRequest else { return nil }
            return APIClient.shared.codableResultTask(with: req, completion: completion)

        // MARK: Settings
        case .getSettings(let completion):
            guard let req = InvoiceRequest.getSettings.urlRequest else { return nil }
            return APIClient.shared.codableResultTask(with: req, completion: completion)

        case .updateSettings(let body, let completion):
            guard let req = InvoiceRequest.updateSettings(body).urlRequest else { return nil }
            return APIClient.shared.dataResultTask(with: req, completion: completion)

        // MARK: Payment Runs
        case .listActiveRuns(let completion):
            guard let req = InvoiceRequest.listActiveRuns.urlRequest else { return nil }
            return APIClient.shared.codableResultTask(with: req, completion: completion)

        case .getActiveRun(let runId, let completion):
            guard let req = InvoiceRequest.getActiveRun(runId).urlRequest else { return nil }
            return APIClient.shared.codableResultTask(with: req, completion: completion)

        case .approveActiveRun(let runId, let body, let completion):
            guard let req = InvoiceRequest.approveActiveRun(runId, body).urlRequest else { return nil }
            return APIClient.shared.dataResultTask(with: req, completion: completion)

        case .rejectActiveRun(let runId, let body, let completion):
            guard let req = InvoiceRequest.rejectActiveRun(runId, body).urlRequest else { return nil }
            return APIClient.shared.dataResultTask(with: req, completion: completion)
        }
    }
}
