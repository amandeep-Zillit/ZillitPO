//
//  InvoiceRequest.swift
//  ZillitPO
//

import Foundation

enum InvoiceRequest {
    // MARK: - Invoices
    case fetchInvoices
    case createInvoice([String: Any])
    case deleteInvoice(String)
    case approveInvoice(String, [String: Any])       // id, body
    case rejectInvoice(String, [String: Any])        // id, body

    // MARK: - Upload
    case uploadInvoice                                // multipart — handled separately

    // MARK: - Approval Tiers
    case fetchInvoiceApprovalTiers

    // MARK: - Settings
    case getSettings
    case updateSettings([String: Any])

    // MARK: - Payment Runs
    case listActiveRuns
    case getActiveRun(String)                         // runId
    case approveActiveRun(String, [String: Any])      // runId, body
    case rejectActiveRun(String, [String: Any])       // runId, body
}

extension InvoiceRequest: POURLRequestProtocol {
    var urlRequest: URLRequest? {
        switch self {

        // MARK: Invoices
        case .fetchInvoices:
            return APIClient.shared.buildRequest(.get, "/api/v2/invoices?per_page=200")

        case .createInvoice(let body):
            return APIClient.shared.buildRequest(.post, "/api/v2/invoices", body: body)

        case .deleteInvoice(let id):
            return APIClient.shared.buildRequest(.delete, "/api/v2/invoices/\(id)")

        case .approveInvoice(let id, let body):
            return APIClient.shared.buildRequest(.post, "/api/v2/invoices/\(id)/approve", body: body)

        case .rejectInvoice(let id, let body):
            return APIClient.shared.buildRequest(.post, "/api/v2/invoices/\(id)/reject", body: body)

        // MARK: Upload (multipart handled via APIClient.buildMultipartRequest)
        case .uploadInvoice:
            return nil // multipart upload built separately

        // MARK: Approval Tiers
        case .fetchInvoiceApprovalTiers:
            return APIClient.shared.buildRequest(.get, "/api/v2/approval-tiers?module=invoices")

        // MARK: Settings
        case .getSettings:
            return APIClient.shared.buildRequest(.get, "/api/v2/invoices/settings")

        case .updateSettings(let body):
            return APIClient.shared.buildRequest(.patch, "/api/v2/invoices/settings", body: body)

        // MARK: Payment Runs
        case .listActiveRuns:
            return APIClient.shared.buildRequest(.get, "/api/v2/invoices/runs/active")

        case .getActiveRun(let runId):
            return APIClient.shared.buildRequest(.get, "/api/v2/invoices/runs/active/\(runId)")

        case .approveActiveRun(let runId, let body):
            return APIClient.shared.buildRequest(.post, "/api/v2/invoices/runs/active/\(runId)/approve", body: body)

        case .rejectActiveRun(let runId, let body):
            return APIClient.shared.buildRequest(.post, "/api/v2/invoices/runs/active/\(runId)/reject", body: body)
        }
    }
}
