//
//  InvoiceState.swift
//  ZillitPO
//

import SwiftUI
import Combine

// MARK: - Invoice Tab / Filter enums

enum InvoiceTab: String, CaseIterable, Identifiable {
    case all = "All Invoices"
    case dept = "My Department"
    case my = "My Invoices"
    var id: String { rawValue }
}

enum InvoiceQuickFilter: String, CaseIterable {
    case all = "All", pending = "Pending", approved = "Approved", rejected = "Rejected"
}

// MARK: - SLA helper

struct SLAInfo {
    let label: String
    let isOverdue: Bool
    let isUrgent: Bool  // 0-1 days
    let daysLeft: Int
}

// MARK: - Invoice Row (precomputed for display)

struct InvoiceRow: Identifiable {
    let id: String
    let ref: String
    let supplier: String
    let gross: String
    let po: String?
    let poVariant: String
    let isUrgent: Bool
    let urgentLabel: String?
    let approvalLabel: String
    let approvalColor: String   // "green", "red", "amber", "gray"
    let sla: SLAInfo
    let chain: [ChainNode]
    let canApprove: Bool
    let approvedCount: Int
    let totalTiers: Int
    let raw: Invoice
}

struct ChainNode: Identifiable {
    let id: Int
    let tier: Int
    let state: String  // "done", "current", "pending"
    let approverUserId: String?
    let expectedUserIds: [String]
}

// MARK: - InvoiceState

class InvoiceState: ObservableObject {
    @Published var invoices: [Invoice] = []
    @Published var vendors: [Vendor] = []
    @Published var tierConfigs: [ApprovalTierConfig] = []
    @Published var isLoading = true
    @Published var vendorsLoaded = false

    // UI state
    @Published var activeTab: InvoiceTab = .all
    @Published var activeFilter: InvoiceQuickFilter = .all
    @Published var detailInvoice: Invoice?
    @Published var deleteTarget: Invoice?
    @Published var deletingId: String?

    // Upload state
    @Published var showUploadPreview = false
    @Published var uploadFileName: String = ""
    @Published var uploadFileData: Data?
    @Published var uploadFileMimeType: String = ""
    @Published var uploading = false
    @Published var uploadError: String?
    @Published var uploadExtraction: InvoiceExtraction?
    @Published var uploadId: String?
    @Published var showTypeSelect = false
    @Published var invoiceType: String?  // "po", "cheque", "wire"
    @Published var uploadSubmitting = false
    @Published var uploadSubmitted = false

    // Reject state
    @Published var showRejectSheet = false
    @Published var rejectTarget: Invoice?
    @Published var rejectReason = ""

    // Payment run state
    @Published var runAuth: [RunAuthLevel] = []
    @Published var pendingRuns: [PaymentRun] = []
    @Published var pendingRunsLoading = false
    @Published var selectedRunDetail: PaymentRunDetail?
    @Published var runDetailLoading = false
    @Published var approvingRunId: String?
    @Published var showRejectRun = false
    @Published var rejectRunReason = ""
    @Published var rejectingRun = false
    @Published var showRunApproval = false

    // User context (set from outside)
    var userId: String = ""
    var currentUser: AppUser?
    var userDeptId: String? { currentUser?.departmentIdentifier }

    func configure(userId: String, currentUser: AppUser?) {
        self.userId = userId
        self.currentUser = currentUser
    }

    var isRunApprover: Bool {
        runAuth.contains { $0.user.contains(userId) }
    }

    // MARK: - Data Loading

    func loadAllData() {
        isLoading = true
        let group = DispatchGroup()

        // Fetch vendors
        group.enter()
        POCodableTask.fetchVendors { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    self?.vendors = response?.data ?? []
                case .failure(let error):
                    print("❌ Invoice: fetch vendors failed: \(error)")
                }
                self?.vendorsLoaded = true
                group.leave()
            }
        }.urlDataTask?.resume()

        // Fetch invoice approval tiers
        group.enter()
        InvoiceCodableTask.fetchInvoiceApprovalTiers { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    self?.tierConfigs = response?.data ?? []
                    print("✅ Invoice tier configs: \(self?.tierConfigs.count ?? 0)")
                case .failure(let error):
                    print("❌ Invoice: fetch tiers failed: \(error)")
                }
                group.leave()
            }
        }.urlDataTask?.resume()

        // Fetch run authorization settings
        group.enter()
        InvoiceCodableTask.getSettings { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if let d = response?.data {
                        self?.parseRunAuth(d)
                    }
                case .failure(let error):
                    print("❌ Invoice: fetch settings failed: \(error)")
                }
                group.leave()
            }
        }.urlDataTask?.resume()

        group.notify(queue: .main) { [weak self] in
            self?.loadInvoices()
        }
    }

    private func parseRunAuth(_ settings: InvoiceSettingsRaw) {
        // run_authorization can be string JSON or already parsed
        if let raVal = settings.run_authorization {
            switch raVal {
            case .string(let s):
                if let data = s.data(using: .utf8),
                   let levels = try? JSONDecoder().decode([RunAuthLevel].self, from: data) {
                    runAuth = levels
                }
            default:
                break
            }
        }
        // If runAuth is still empty, try decoding the raw JSON again
        // The API may return it as an array directly — handled by the Codable path
    }

    func loadInvoices() {
        guard vendorsLoaded else { return }
        InvoiceCodableTask.fetchInvoices { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    let raw = response?.data ?? []
                    let v = self?.vendors ?? []
                    let d = DepartmentsData.all
                    self?.invoices = raw.map { $0.toInvoice(vendors: v, departments: d) }
                    print("✅ Loaded \(self?.invoices.count ?? 0) invoices")
                case .failure(let error):
                    print("❌ Fetch invoices failed: \(error)")
                }
                self?.isLoading = false
            }
        }.urlDataTask?.resume()
    }

    // MARK: - Filtered Invoices

    var filteredInvoices: [Invoice] {
        guard currentUser != nil else { return [] }
        var list = invoices

        switch activeTab {
        case .my:
            list = list.filter { $0.userId == userId }
        case .dept:
            list = list.filter { inv in
                let deptId = inv.departmentId ?? ""
                let dept = DepartmentsData.all.first { d in d.id == deptId || d.identifier == deptId }
                return dept?.identifier == userDeptId
            }
        case .all:
            list = list.filter { inv in
                if inv.userId == userId { return true }
                if inv.status == "inbox" { return false }
                let dept = DepartmentsData.all.first { d in d.id == (inv.departmentId ?? "") || d.identifier == (inv.departmentId ?? "") }
                if dept?.identifier == userDeptId { return true }
                if inv.status == "approval" { return true }
                return false
            }
        }

        switch activeFilter {
        case .all: break
        case .pending:
            list = list.filter { ($0.approvalStatus) == "pending" }
        case .approved:
            list = list.filter { $0.approvalStatus == "approved" }
        case .rejected:
            list = list.filter { $0.approvalStatus == "rejected" }
        }

        return list.sorted { $0.createdAt > $1.createdAt }
    }

    // MARK: - Build rows

    func buildRows() -> [InvoiceRow] {
        filteredInvoices.map { inv in
            let config = ApprovalHelpers.resolveConfig(tierConfigs, deptId: inv.departmentId, amount: inv.grossAmount)
            let totalTiers = ApprovalHelpers.getTotalTiers(config)
            let mappedStatus = inv.status == "approval" ? "PENDING" : inv.status.uppercased()
            let fakePO = PurchaseOrder(id: inv.id, projectId: inv.projectId, userId: inv.userId,
                                       poNumber: "", vendorId: inv.vendorId, departmentId: inv.departmentId,
                                       status: mappedStatus, approvals: inv.approvals, createdAt: inv.createdAt)
            let vis = ApprovalHelpers.getVisibility(po: fakePO, config: config ?? [:], userId: userId)
            let nextTier = vis.nextTier
            let approvedCount = inv.approvals.count

            // Build chain
            var chain: [ChainNode] = []
            for t in 1...max(totalTiers, 1) {
                let app = inv.approvals.first { $0.tierNumber == t }
                let tierKey = String(t)
                let entries = config?[tierKey] ?? []
                let expectedUserIds = entries.map { $0.userId }
                chain.append(ChainNode(
                    id: t, tier: t,
                    state: app != nil ? "done" : (t == nextTier ? "current" : "pending"),
                    approverUserId: app?.userId,
                    expectedUserIds: expectedUserIds
                ))
            }
            if totalTiers == 0 { chain = [] }

            let sla = Self.getSLAInfo(dueDateMs: inv.dueDate)

            // Approval status display
            let approvalLabel: String
            let approvalColor: String
            let isUrgent = inv.payMethod == "wire" || inv.payMethod == "cheque"

            if isUrgent {
                if inv.approvalStatus == "approved" || inv.status == "override" {
                    approvalLabel = "Approved"; approvalColor = "green"
                } else {
                    approvalLabel = "No PO"; approvalColor = "pink"
                }
            } else if inv.approvalStatus == "approved" || inv.status == "approved" || inv.status == "override" {
                approvalLabel = "Approved"; approvalColor = "green"
            } else if inv.approvalStatus == "rejected" || inv.status == "rejected" {
                approvalLabel = "Rejected"; approvalColor = "red"
            } else if inv.status == "approval" && totalTiers > 0 {
                approvalLabel = "Pending (\(approvedCount)/\(totalTiers))"; approvalColor = "amber"
            } else {
                approvalLabel = "Pending"; approvalColor = "gray"
            }

            let po: String?
            if isUrgent {
                po = nil
            } else {
                po = inv.poNumber ?? (inv.poId != nil ? "PO-\(inv.poId!.prefix(4))" : "No PO")
            }

            return InvoiceRow(
                id: inv.id,
                ref: inv.invoiceNumber.isEmpty ? String(inv.id.prefix(8)).uppercased() : inv.invoiceNumber,
                supplier: inv.vendor.isEmpty ? "Unknown" : inv.vendor,
                gross: Self.formatCurrency(inv.grossAmount, currency: inv.currency),
                po: po,
                poVariant: inv.poId != nil ? "blue" : "pink",
                isUrgent: isUrgent,
                urgentLabel: inv.payMethod == "wire" ? "Urgent Wire Request" : (inv.payMethod == "cheque" ? "Cheque Request" : nil),
                approvalLabel: approvalLabel,
                approvalColor: approvalColor,
                sla: sla,
                chain: chain,
                canApprove: vis.canApprove,
                approvedCount: approvedCount,
                totalTiers: totalTiers,
                raw: inv
            )
        }
    }

    // MARK: - Stats

    var pendingCount: Int { filteredInvoices.filter { $0.approvalStatus == "pending" }.count }
    var approvedCount: Int { filteredInvoices.filter { $0.approvalStatus == "approved" }.count }
    var totalValue: Double { filteredInvoices.reduce(0) { $0 + $1.grossAmount } }

    // MARK: - Actions

    func approveInvoice(_ inv: Invoice) {
        let config = ApprovalHelpers.resolveConfig(tierConfigs, deptId: inv.departmentId, amount: inv.grossAmount)
        let totalTiers = ApprovalHelpers.getTotalTiers(config)
        let mappedStatus = inv.status == "approval" ? "PENDING" : inv.status.uppercased()
        let fakePO = PurchaseOrder(id: inv.id, projectId: inv.projectId, userId: inv.userId,
                                   poNumber: "", vendorId: inv.vendorId, departmentId: inv.departmentId,
                                   status: mappedStatus, approvals: inv.approvals, createdAt: inv.createdAt)
        let vis = ApprovalHelpers.getVisibility(po: fakePO, config: config ?? [:], userId: userId)
        guard vis.canApprove, let next = vis.nextTier else { return }

        let body: [String: Any] = ["tier_number": next, "total_tiers": totalTiers > 0 ? totalTiers : 1]
        InvoiceCodableTask.approveInvoice(inv.id, body) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success: self?.loadInvoices(); self?.detailInvoice = nil
                case .failure(let error): print("❌ Approve invoice failed: \(error)")
                }
            }
        }.urlDataTask?.resume()
    }

    func rejectInvoice(_ inv: Invoice, reason: String) {
        let body: [String: Any] = ["reason": reason.trimmingCharacters(in: .whitespaces)]
        InvoiceCodableTask.rejectInvoice(inv.id, body) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self?.loadInvoices()
                    self?.detailInvoice = nil
                    self?.rejectTarget = nil
                    self?.rejectReason = ""
                    self?.showRejectSheet = false
                case .failure(let error):
                    print("❌ Reject invoice failed: \(error)")
                }
            }
        }.urlDataTask?.resume()
    }

    func deleteInvoice(_ inv: Invoice) {
        deletingId = inv.id
        deleteTarget = nil
        InvoiceCodableTask.deleteInvoice(inv.id) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success: self?.loadInvoices()
                case .failure(let error): print("❌ Delete invoice failed: \(error)")
                }
                self?.deletingId = nil
            }
        }.urlDataTask?.resume()
    }

    // MARK: - Upload

    func uploadFile(_ data: Data, fileName: String, mimeType: String) {
        uploading = true
        uploadError = nil
        uploadExtraction = nil
        uploadId = nil
        InvoiceCodableTask.uploadInvoice(data, fileName, mimeType) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if let ext = response?.data {
                        self?.uploadExtraction = ext
                        self?.uploadId = ext.upload_id
                    }
                case .failure(let error):
                    self?.uploadError = error.localizedDescription
                }
                self?.uploading = false
            }
        }.urlDataTask?.resume()
    }

    func submitUpload() {
        guard let ext = uploadExtraction, let type = invoiceType else { return }
        uploadSubmitting = true
        let gross = Double(ext.gross ?? "0") ?? 0
        let payMethod: String = {
            switch type {
            case "wire": return "wire"
            case "cheque": return "cheque"
            default: return ext.pay_method ?? "bacs"
            }
        }()
        let defaultDept = DepartmentsData.all.first { $0.identifier == currentUser?.departmentIdentifier }?.id ?? ""

        var body: [String: Any] = [
            "description": ext.supplier?.name.map { "Invoice — \($0)" } ?? (uploadFileName.replacingOccurrences(of: "\\.[^.]+$", with: "", options: .regularExpression) ),
            "gross_amount": gross,
            "pay_method": payMethod,
            "currency": ext.currency ?? "GBP",
        ]
        if let d = ext.invoice_date { body["invoice_date"] = d }
        if let d = ext.due_date { body["due_date"] = d }
        if let p = ext.po_number, !p.isEmpty { body["po_number"] = p }
        if !defaultDept.isEmpty { body["department_id"] = defaultDept }
        if let uid = uploadId { body["upload_id"] = uid }

        InvoiceCodableTask.createInvoice(body) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self?.uploadSubmitted = true
                    self?.uploadSubmitting = false
                    self?.showTypeSelect = false
                    self?.loadInvoices()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        self?.closeUpload()
                    }
                case .failure(let error):
                    self?.uploadError = error.localizedDescription
                    self?.uploadSubmitting = false
                }
            }
        }.urlDataTask?.resume()
    }

    func closeUpload() {
        showUploadPreview = false
        uploadFileName = ""
        uploadFileData = nil
        uploadFileMimeType = ""
        uploading = false
        uploadError = nil
        uploadExtraction = nil
        uploadId = nil
        showTypeSelect = false
        invoiceType = nil
        uploadSubmitting = false
        uploadSubmitted = false
    }

    // MARK: - Payment Runs

    func fetchPendingRuns() {
        guard isRunApprover else { return }
        pendingRunsLoading = true
        InvoiceCodableTask.listActiveRuns { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    let allRuns = (response?.data ?? []).map { $0.toPaymentRun() }
                    let uid = self?.userId ?? ""
                    let auth = self?.runAuth ?? []
                    let sortedAuth = auth.sorted { $0.tier < $1.tier }
                    self?.pendingRuns = allRuns.filter { run in
                        guard run.status == "pending" else { return false }
                        let nextLevel = sortedAuth.first { level in
                            !run.approval.contains { $0.tierNumber == level.tier }
                        }
                        return nextLevel?.user.contains(uid) ?? false
                    }
                case .failure(let error):
                    print("❌ Fetch pending runs failed: \(error)")
                    self?.pendingRuns = []
                }
                self?.pendingRunsLoading = false
            }
        }.urlDataTask?.resume()
    }

    func openRunDetail(_ runId: String) {
        runDetailLoading = true
        selectedRunDetail = PaymentRunDetail(run: PaymentRun(id: runId), invoices: [])
        InvoiceCodableTask.getActiveRun(runId) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if let raw = response?.data {
                        let run = raw.run?.toPaymentRun() ?? PaymentRun(id: runId)
                        let v = self?.vendors ?? []
                        let d = DepartmentsData.all
                        let invoices = (raw.invoices ?? []).map { $0.toInvoice(vendors: v, departments: d) }
                        self?.selectedRunDetail = PaymentRunDetail(run: run, invoices: invoices)
                    }
                case .failure(let error):
                    print("❌ Fetch run detail failed: \(error)")
                    self?.selectedRunDetail = nil
                }
                self?.runDetailLoading = false
            }
        }.urlDataTask?.resume()
    }

    func approveRun() {
        guard let detail = selectedRunDetail else { return }
        let sortedAuth = runAuth.sorted { $0.tier < $1.tier }
        let nextLevel = sortedAuth.first { level in
            !detail.run.approval.contains { $0.tierNumber == level.tier }
        }
        guard let level = nextLevel else { return }
        approvingRunId = detail.run.id
        let body: [String: Any] = ["tier_number": level.tier, "total_tiers": sortedAuth.count]
        InvoiceCodableTask.approveActiveRun(detail.run.id, body) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self?.openRunDetail(detail.run.id)
                    self?.fetchPendingRuns()
                case .failure(let error):
                    print("❌ Approve run failed: \(error)")
                }
                self?.approvingRunId = nil
            }
        }.urlDataTask?.resume()
    }

    func rejectRun() {
        guard let detail = selectedRunDetail, !rejectRunReason.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        rejectingRun = true
        let body: [String: Any] = ["reason": rejectRunReason.trimmingCharacters(in: .whitespaces)]
        InvoiceCodableTask.rejectActiveRun(detail.run.id, body) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self?.selectedRunDetail = nil
                    self?.showRejectRun = false
                    self?.rejectRunReason = ""
                    self?.fetchPendingRuns()
                case .failure(let error):
                    print("❌ Reject run failed: \(error)")
                }
                self?.rejectingRun = false
            }
        }.urlDataTask?.resume()
    }

    // MARK: - Helpers

    static func formatCurrency(_ amount: Double, currency: String = "GBP") -> String {
        let sym: String = {
            switch currency.uppercased() {
            case "GBP": return "£"
            case "USD": return "$"
            case "EUR": return "€"
            default: return currency + " "
            }
        }()
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        formatter.locale = Locale(identifier: "en_GB")
        return sym + (formatter.string(from: NSNumber(value: amount)) ?? "0.00")
    }

    static func getSLAInfo(dueDateMs: Int64?) -> SLAInfo {
        guard let ms = dueDateMs, ms > 0 else {
            return SLAInfo(label: "—", isOverdue: false, isUrgent: false, daysLeft: 999)
        }
        let now = Calendar.current.startOfDay(for: Date())
        let due = Calendar.current.startOfDay(for: Date(timeIntervalSince1970: Double(ms) / 1000.0))
        let diff = Calendar.current.dateComponents([.day], from: now, to: due).day ?? 0
        if diff < 0 {
            return SLAInfo(label: "\(abs(diff))d overdue", isOverdue: true, isUrgent: true, daysLeft: diff)
        }
        if diff == 0 {
            return SLAInfo(label: "Same day", isOverdue: false, isUrgent: true, daysLeft: 0)
        }
        if diff == 1 {
            return SLAInfo(label: "1 day left", isOverdue: false, isUrgent: true, daysLeft: 1)
        }
        return SLAInfo(label: "\(diff) days left", isOverdue: false, isUrgent: diff <= 3, daysLeft: diff)
    }

    static func formatDateOnly(_ ms: Int64?) -> String {
        guard let ms = ms, ms > 0 else { return "—" }
        let d = Date(timeIntervalSince1970: Double(ms) / 1000.0)
        let f = DateFormatter()
        f.dateFormat = "dd MMM yyyy"
        f.locale = Locale(identifier: "en_GB")
        return f.string(from: d)
    }

    static func formatDateTime(_ ms: Int64?) -> String {
        guard let ms = ms, ms > 0 else { return "—" }
        let d = Date(timeIntervalSince1970: Double(ms) / 1000.0)
        let df = DateFormatter()
        df.dateFormat = "dd MMM yyyy"
        df.locale = Locale(identifier: "en_GB")
        let tf = DateFormatter()
        tf.dateFormat = "h:mm a"
        tf.locale = Locale(identifier: "en_GB")
        return "\(df.string(from: d)) | \(tf.string(from: d).uppercased())"
    }
}

// MARK: - PurchaseOrder convenience init for approval visibility mapping

extension PurchaseOrder {
    init(id: String, projectId: String, userId: String, poNumber: String,
         vendorId: String?, departmentId: String?, status: String,
         approvals: [Approval], createdAt: Int64) {
        self.init()
        self.id = id; self.projectId = projectId; self.userId = userId
        self.poNumber = poNumber; self.vendorId = vendorId; self.departmentId = departmentId
        self.status = status; self.approvals = approvals; self.createdAt = createdAt
    }
}
