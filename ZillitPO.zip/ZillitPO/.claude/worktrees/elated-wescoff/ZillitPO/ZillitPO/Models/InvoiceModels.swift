//
//  InvoiceModels.swift
//  ZillitPO
//

import Foundation

// MARK: - Invoice Status

enum InvoiceStatus: String, CaseIterable {
    case inbox = "inbox"
    case approval = "approval"
    case approved = "approved"
    case rejected = "rejected"
    case override_ = "override"
    case posted = "posted"

    var displayName: String {
        switch self {
        case .inbox: return "Inbox"
        case .approval: return "Pending"
        case .approved: return "Approved"
        case .rejected: return "Rejected"
        case .override_: return "Override"
        case .posted: return "Posted"
        }
    }

    static func fromAPI(_ raw: String) -> InvoiceStatus {
        InvoiceStatus(rawValue: raw.lowercased()) ?? .approval
    }
}

// MARK: - Invoice (domain model)

struct Invoice: Identifiable, Equatable {
    var id: String = UUID().uuidString
    var projectId: String = ""
    var userId: String = ""
    var invoiceNumber: String = ""
    var vendorId: String?
    var departmentId: String?
    var description: String?
    var grossAmount: Double = 0
    var currency: String = "GBP"
    var invoiceDate: Int64?
    var dueDate: Int64?
    var status: String = "inbox"
    var approvalStatus: String = "pending"
    var payMethod: String = "bacs"
    var poNumber: String?
    var poId: String?
    var approvals: [Approval] = []
    var rejectionReason: String?
    var uploadId: String?
    var createdAt: Int64 = 0
    var updatedAt: Int64 = 0

    // Display fields (resolved)
    var vendor: String = ""
    var department: String = ""

    static func == (lhs: Invoice, rhs: Invoice) -> Bool { lhs.id == rhs.id }
    var invoiceStatus: InvoiceStatus { InvoiceStatus.fromAPI(status) }
}

// MARK: - InvoiceRaw (flexible API decoding)

struct InvoiceRaw: Codable {
    var id: String
    var project_id: String?
    var user_id: String?
    var invoice_number: String?
    var vendor_id: String?
    var department_id: String?
    var description: String?
    var gross_amount: AnyCodableValue?
    var currency: String?
    var invoice_date: Int?
    var due_date: Int?
    var status: String?
    var approval_status: String?
    var pay_method: String?
    var po_number: String?
    var po_id: String?
    var approvals: FlexibleApprovals?
    var rejection_reason: String?
    var upload_id: String?
    var created_at: Int?
    var updated_at: Int?

    enum CodingKeys: String, CodingKey {
        case id, project_id, user_id, invoice_number, vendor_id, department_id, description
        case gross_amount, currency, invoice_date, due_date, status, approval_status
        case pay_method, po_number, po_id, approvals, rejection_reason, upload_id
        case created_at, updated_at
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        project_id = try? c.decode(String.self, forKey: .project_id)
        user_id = try? c.decode(String.self, forKey: .user_id)
        invoice_number = try? c.decode(String.self, forKey: .invoice_number)
        vendor_id = try? c.decode(String.self, forKey: .vendor_id)
        department_id = try? c.decode(String.self, forKey: .department_id)
        description = try? c.decode(String.self, forKey: .description)
        gross_amount = try? c.decode(AnyCodableValue.self, forKey: .gross_amount)
        currency = try? c.decode(String.self, forKey: .currency)
        status = try? c.decode(String.self, forKey: .status)
        approval_status = try? c.decode(String.self, forKey: .approval_status)
        pay_method = try? c.decode(String.self, forKey: .pay_method)
        po_number = try? c.decode(String.self, forKey: .po_number)
        po_id = try? c.decode(String.self, forKey: .po_id)
        approvals = try? c.decode(FlexibleApprovals.self, forKey: .approvals)
        rejection_reason = try? c.decode(String.self, forKey: .rejection_reason)
        upload_id = try? c.decode(String.self, forKey: .upload_id)
        invoice_date = flexibleIntDecode(c, .invoice_date)
        due_date = flexibleIntDecode(c, .due_date)
        created_at = flexibleIntDecode(c, .created_at)
        updated_at = flexibleIntDecode(c, .updated_at)
    }
}

extension InvoiceRaw {
    func toInvoice(vendors: [Vendor], departments: [Department]) -> Invoice {
        let v = vendors.first { $0.id == (vendor_id ?? "") }
        let d = departments.first { $0.id == (department_id ?? "") || $0.identifier == (department_id ?? "") }
        let apps = (approvals?.items ?? []).map {
            Approval(userId: $0.user_id ?? "", tierNumber: $0.tier_number ?? 0, approvedAt: Int64($0.approved_at ?? 0))
        }
        var inv = Invoice()
        inv.id = id
        inv.projectId = project_id ?? ""
        inv.userId = user_id ?? ""
        inv.invoiceNumber = invoice_number ?? ""
        inv.vendorId = vendor_id
        inv.departmentId = department_id
        inv.description = description
        inv.grossAmount = gross_amount?.doubleValue ?? 0
        inv.currency = currency ?? "GBP"
        inv.invoiceDate = invoice_date.map { Int64($0) }
        inv.dueDate = due_date.map { Int64($0) }
        inv.status = status ?? "inbox"
        inv.approvalStatus = approval_status ?? "pending"
        inv.payMethod = pay_method ?? "bacs"
        inv.poNumber = po_number
        inv.poId = po_id
        inv.approvals = apps
        inv.rejectionReason = rejection_reason
        inv.uploadId = upload_id
        inv.createdAt = Int64(created_at ?? 0)
        inv.updatedAt = Int64(updated_at ?? 0)
        inv.vendor = v?.name ?? ""
        inv.department = d?.displayName ?? ""
        return inv
    }
}

// MARK: - Payment Run models

struct PaymentRun: Identifiable, Equatable {
    var id: String = ""
    var number: String = ""
    var name: String = ""
    var status: String = "pending"
    var payMethod: String = "bacs"
    var totalAmount: Double = 0
    var invoiceCount: Int = 0
    var approval: [Approval] = []
    var createdBy: String = ""
    var createdAt: Int64 = 0

    static func == (lhs: PaymentRun, rhs: PaymentRun) -> Bool { lhs.id == rhs.id }
}

struct PaymentRunRaw: Codable {
    var id: String
    var number: String?
    var name: String?
    var status: String?
    var pay_method: String?
    var total_amount: AnyCodableValue?
    var computed_total: AnyCodableValue?
    var invoice_count: Int?
    var approval: FlexibleApprovals?
    var created_by: String?
    var created_at: Int?

    enum CodingKeys: String, CodingKey {
        case id, number, name, status, pay_method, total_amount, computed_total
        case invoice_count, approval, created_by, created_at
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        number = try? c.decode(String.self, forKey: .number)
        name = try? c.decode(String.self, forKey: .name)
        status = try? c.decode(String.self, forKey: .status)
        pay_method = try? c.decode(String.self, forKey: .pay_method)
        total_amount = try? c.decode(AnyCodableValue.self, forKey: .total_amount)
        computed_total = try? c.decode(AnyCodableValue.self, forKey: .computed_total)
        invoice_count = flexibleIntDecode(c, .invoice_count)
        approval = try? c.decode(FlexibleApprovals.self, forKey: .approval)
        created_by = try? c.decode(String.self, forKey: .created_by)
        created_at = flexibleIntDecode(c, .created_at)
    }

    func toPaymentRun() -> PaymentRun {
        let apps = (approval?.items ?? []).map {
            Approval(userId: $0.user_id ?? "", tierNumber: $0.tier_number ?? 0, approvedAt: Int64($0.approved_at ?? 0))
        }
        var run = PaymentRun()
        run.id = id
        run.number = number ?? ""
        run.name = name ?? ""
        run.status = status ?? "pending"
        run.payMethod = pay_method ?? "bacs"
        run.totalAmount = total_amount?.doubleValue ?? computed_total?.doubleValue ?? 0
        run.invoiceCount = invoice_count ?? 0
        run.approval = apps
        run.createdBy = created_by ?? ""
        run.createdAt = Int64(created_at ?? 0)
        return run
    }
}

struct PaymentRunDetailRaw: Codable {
    var run: PaymentRunRaw?
    var invoices: [InvoiceRaw]?

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        run = try? c.decode(PaymentRunRaw.self, forKey: .run)
        invoices = try? c.decode([InvoiceRaw].self, forKey: .invoices)
    }

    enum CodingKeys: String, CodingKey { case run, invoices }
}

struct PaymentRunDetail {
    var run: PaymentRun
    var invoices: [Invoice]
}

// MARK: - Run Authorization Level

struct RunAuthLevel: Codable, Equatable {
    var tier: Int
    var user: [String]
}

// MARK: - Invoice Settings

struct InvoiceSettingsRaw: Codable {
    var alerts: AnyCodableValue?
    var team_members: AnyCodableValue?
    var run_authorization: AnyCodableValue?
    var assignment_rules: [POAssignmentRule]?

    enum CodingKeys: String, CodingKey {
        case alerts, team_members, run_authorization, assignment_rules
    }
}

// MARK: - Upload extraction result

struct InvoiceExtraction: Codable {
    var upload_id: String?
    var supplier: InvoiceExtractionSupplier?
    var invoice_date: String?
    var due_date: String?
    var gross: String?
    var po_number: String?
    var currency: String?
    var pay_method: String?

    struct InvoiceExtractionSupplier: Codable {
        var name: String?
    }
}
