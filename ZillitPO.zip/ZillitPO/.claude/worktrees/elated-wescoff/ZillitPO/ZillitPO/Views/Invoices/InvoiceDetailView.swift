//
//  InvoiceDetailView.swift
//  ZillitPO
//

import SwiftUI

// MARK: - Invoice Detail Page (push destination)

struct InvoiceDetailPage: View {
    let invoice: Invoice
    let row: InvoiceRow
    @ObservedObject var invoiceState: InvoiceState
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        InvoiceDetailContentView(invoice: invoice, row: row, invoiceState: invoiceState)
            .navigationBarTitle("", displayMode: .inline)
            .navigationBarBackButtonHidden(true)
            .navigationBarItems(leading:
                Button { presentationMode.wrappedValue.dismiss() } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "chevron.left").font(.system(size: 14, weight: .semibold))
                        Text("Back").font(.system(size: 15))
                    }.foregroundColor(.gold)
                }
            )
    }
}

// MARK: - Invoice Detail Content

struct InvoiceDetailContentView: View {
    let invoice: Invoice
    let row: InvoiceRow
    @ObservedObject var invoiceState: InvoiceState

    @State private var approving = false
    @State private var showReject = false
    @State private var rejectReason = ""
    @State private var rejecting = false

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                headerSection
                detailsCard
                if !row.chain.isEmpty && invoice.payMethod != "wire" && invoice.payMethod != "cheque" &&
                   (invoice.status == "approval" || invoice.status == "approved" || invoice.status == "rejected") {
                    approvalChainSection
                }
                if let reason = invoice.rejectionReason, !reason.isEmpty {
                    rejectionSection(reason)
                }
                creatorSection
            }
            .padding(16)
        }
        .background(Color.bgBase.edgesIgnoringSafeArea(.all))
        .overlay(
            Group {
                if row.canApprove && invoice.status == "approval" {
                    VStack {
                        Spacer()
                        actionBar
                    }
                }
            }
        )
        .sheet(isPresented: $showReject) {
            InvoiceRejectSheetView(
                invoiceRef: invoice.invoiceNumber,
                reason: $rejectReason,
                rejecting: $rejecting,
                onReject: {
                    rejecting = true
                    invoiceState.rejectInvoice(invoice, reason: rejectReason)
                },
                onCancel: { showReject = false }
            )
        }
    }

    // MARK: - Header

    private var headerSection: some View {
        VStack(spacing: 8) {
            Text(invoice.invoiceNumber.isEmpty ? "—" : invoice.invoiceNumber)
                .font(.system(size: 18, weight: .bold, design: .monospaced))
                .foregroundColor(.goldDark)

            HStack(spacing: 6) {
                statusBadge
                if let po = row.po {
                    BadgeView(text: po, color: row.poVariant == "blue" ? .blue : .pink)
                }
                slaBadge
            }

            if let desc = invoice.description, !desc.isEmpty {
                Text(desc)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderColor, lineWidth: 1))
    }

    private var statusBadge: some View {
        Group {
            if row.isUrgent {
                if invoice.approvalStatus == "approved" || invoice.status == "override" {
                    BadgeView(text: "Approved", color: .green)
                } else {
                    BadgeView(text: row.urgentLabel ?? "Urgent", color: .rejectPink)
                }
            } else {
                BadgeView(text: row.approvalLabel, color: badgeColor(row.approvalColor))
            }
        }
    }

    private var slaBadge: some View {
        BadgeView(
            text: row.sla.label,
            color: row.sla.isOverdue ? .pink : (row.sla.isUrgent ? .orange : .blue)
        )
    }

    // MARK: - Details Card

    private var detailsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            detailRow("Vendor", invoice.vendor.isEmpty ? "—" : invoice.vendor)
            detailRow("Department", invoice.department.isEmpty ? "—" : invoice.department)

            HStack(spacing: 16) {
                detailColumn("Currency", invoice.currency)
                detailColumn("Payment", invoice.payMethod.uppercased())
            }

            HStack(spacing: 16) {
                detailColumn("Invoice Date", InvoiceState.formatDateOnly(invoice.invoiceDate))
                detailColumn("Due Date", InvoiceState.formatDateOnly(invoice.dueDate))
            }

            Divider()

            HStack {
                Text("GROSS").font(.system(size: 10, weight: .bold)).foregroundColor(.gray)
                Spacer()
                Text(InvoiceState.formatCurrency(invoice.grossAmount, currency: invoice.currency))
                    .font(.system(size: 16, weight: .bold, design: .monospaced))
            }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderColor, lineWidth: 1))
    }

    private func detailRow(_ label: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label.uppercased()).font(.system(size: 10, weight: .bold)).foregroundColor(.gray)
            Text(value).font(.system(size: 14, weight: .semibold))
        }
    }

    private func detailColumn(_ label: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label.uppercased()).font(.system(size: 10, weight: .bold)).foregroundColor(.gray)
            Text(value).font(.system(size: 13, weight: .semibold))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: - Approval Chain

    private var approvalChainSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("APPROVAL CHAIN")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.gray)

            HStack(spacing: 0) {
                ForEach(row.chain) { node in
                    HStack(spacing: 0) {
                        VStack(spacing: 4) {
                            chainCircle(node)
                            chainLabel(node)
                        }
                        .frame(width: 80)

                        if node.tier < row.totalTiers {
                            Rectangle()
                                .fill(node.state == "done" ? Color.green.opacity(0.6) : Color.gray.opacity(0.2))
                                .frame(width: 24, height: 2)
                                .offset(y: -12)
                        }
                    }
                }
            }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderColor, lineWidth: 1))
    }

    private func chainCircle(_ node: ChainNode) -> some View {
        Group {
            if node.state == "done" {
                ZStack {
                    Circle().fill(Color.green).frame(width: 28, height: 28)
                    Image(systemName: "checkmark").font(.system(size: 12, weight: .bold)).foregroundColor(.white)
                }
            } else if node.state == "current" {
                ZStack {
                    Circle().fill(Color.gold).frame(width: 28, height: 28)
                    Circle().fill(Color.white).frame(width: 10, height: 10)
                }
            } else {
                Circle().stroke(Color.gray.opacity(0.4), lineWidth: 2).frame(width: 28, height: 28)
            }
        }
    }

    private func chainLabel(_ node: ChainNode) -> some View {
        Group {
            if node.state == "done", let uid = node.approverUserId, let user = UsersData.byId[uid] {
                VStack(spacing: 1) {
                    Text(user.fullName).font(.system(size: 9, weight: .semibold)).foregroundColor(.green)
                    Text(user.displayDesignation).font(.system(size: 8)).foregroundColor(.green.opacity(0.7))
                }
            } else if !node.expectedUserIds.isEmpty {
                let names = node.expectedUserIds.compactMap { UsersData.byId[$0]?.fullName }
                Text(names.joined(separator: ", "))
                    .font(.system(size: 9, weight: node.state == "current" ? .semibold : .regular))
                    .foregroundColor(node.state == "current" ? .goldDark : .gray)
            } else {
                Text("Awaiting").font(.system(size: 9)).foregroundColor(.gray)
            }
        }
        .lineLimit(2)
        .multilineTextAlignment(.center)
    }

    // MARK: - Rejection

    private func rejectionSection(_ reason: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("REJECTION REASON")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.rejectPink)
            Text(reason)
                .font(.system(size: 13))
                .foregroundColor(.primary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Color.rejectPink.opacity(0.08))
        .cornerRadius(8)
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.rejectPink.opacity(0.3), lineWidth: 1))
    }

    // MARK: - Creator

    private var creatorSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("CREATED BY").font(.system(size: 10, weight: .bold)).foregroundColor(.gray)
            if let creator = UsersData.byId[invoice.userId] {
                Text(creator.fullName).font(.system(size: 13, weight: .semibold))
                Text(creator.displayDesignation).font(.system(size: 11)).foregroundColor(.secondary)
            } else {
                Text("—").font(.system(size: 13))
            }
            Text(InvoiceState.formatDateTime(invoice.createdAt))
                .font(.system(size: 11)).foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderColor, lineWidth: 1))
        .padding(.bottom, row.canApprove && invoice.status == "approval" ? 60 : 0)
    }

    // MARK: - Action Bar

    private var actionBar: some View {
        HStack(spacing: 12) {
            Button {
                showReject = true
            } label: {
                Text("Reject")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color.rejectPink)
                    .cornerRadius(8)
            }

            Button {
                approving = true
                invoiceState.approveInvoice(invoice)
            } label: {
                Text(approving ? "Approving..." : "Approve")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color.gold)
                    .cornerRadius(8)
            }
            .disabled(approving)
            .opacity(approving ? 0.6 : 1)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.white.shadow(radius: 4, y: -2))
    }

    private func badgeColor(_ name: String) -> Color {
        switch name {
        case "green": return .green
        case "red", "pink": return .rejectPink
        case "amber": return .orange
        default: return .gray
        }
    }
}

// MARK: - Badge View

struct BadgeView: View {
    let text: String
    let color: Color

    var body: some View {
        Text(text)
            .font(.system(size: 10, weight: .semibold))
            .foregroundColor(color)
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(color.opacity(0.12))
            .cornerRadius(4)
            .overlay(RoundedRectangle(cornerRadius: 4).stroke(color.opacity(0.3), lineWidth: 0.5))
    }
}

// MARK: - Invoice Reject Sheet

struct InvoiceRejectSheetView: View {
    let invoiceRef: String
    @Binding var reason: String
    @Binding var rejecting: Bool
    var onReject: () -> Void
    var onCancel: () -> Void

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                Text("Provide a reason for rejecting this invoice.")
                    .font(.system(size: 13))
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)

                TextField("Rejection reason...", text: $reason)
                    .textFieldStyle(RoundedBorderTextFieldStyle())

                if reason.trimmingCharacters(in: .whitespaces).isEmpty {
                    Text("Rejection reason is required")
                        .font(.system(size: 11))
                        .foregroundColor(.rejectPink)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }

                Spacer()

                HStack(spacing: 12) {
                    Button("Cancel") { onCancel() }
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.borderColor))

                    Button(rejecting ? "Rejecting..." : "Reject") {
                        onReject()
                    }
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(reason.trimmingCharacters(in: .whitespaces).isEmpty || rejecting ? Color.gray : Color.rejectPink)
                    .cornerRadius(8)
                    .disabled(reason.trimmingCharacters(in: .whitespaces).isEmpty || rejecting)
                }
            }
            .padding(20)
            .navigationBarTitle("Reject \(invoiceRef)", displayMode: .inline)
        }
    }
}

// MARK: - Color extension for reject pink

extension Color {
    static let rejectPink = Color(red: 232/255, green: 75/255, blue: 122/255)
}
