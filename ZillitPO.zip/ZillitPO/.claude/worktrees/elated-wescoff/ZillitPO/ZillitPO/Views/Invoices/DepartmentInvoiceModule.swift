//
//  DepartmentInvoiceModule.swift
//  ZillitPO
//

import SwiftUI

// MARK: - Main Invoice Module

struct DepartmentInvoiceModule: View {
    var userId: String = ""
    var currentUser: AppUser?
    @StateObject private var invoiceState = InvoiceState()

    // Navigation state
    @State private var showDetail = false
    @State private var selectedRow: InvoiceRow?

    // Upload
    @State private var showDocPicker = false

    // Tabs
    @State private var showRunTab = false

    var body: some View {
        ZStack {
            Color.bgBase.edgesIgnoringSafeArea(.all)

            VStack(spacing: 0) {
                // Header
                VStack(alignment: .leading, spacing: 4) {
                    Text("INVOICES").font(.system(size: 10, weight: .bold)).foregroundColor(.gray)
                        .tracking(1.5)
                    Text("Invoices").font(.system(size: 22, weight: .bold))
                    Text("View and manage invoices.")
                        .font(.system(size: 12)).foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 8)

                // Tab bar
                tabBar

                // Content
                if showRunTab {
                    ScrollView {
                        PaymentRunListView(invoiceState: invoiceState)
                            .padding(.horizontal, 16)
                            .padding(.top, 8)
                    }
                } else {
                    // Quick filters
                    quickFilters

                    // Invoice list
                    invoiceList
                }
            }

            // Hidden NavigationLink for detail push
            NavigationLink(
                destination: Group {
                    if let row = selectedRow {
                        InvoiceDetailPage(invoice: row.raw, row: row, invoiceState: invoiceState)
                    }
                },
                isActive: $showDetail
            ) { EmptyView() }.hidden()
        }
        .onAppear {
            invoiceState.configure(userId: userId, currentUser: currentUser)
            invoiceState.loadAllData()
        }
        .sheet(isPresented: $invoiceState.showUploadPreview) {
            InvoiceUploadPreviewView(invoiceState: invoiceState)
        }
        .sheet(isPresented: $showDocPicker) {
            InvoiceDocumentPicker(invoiceState: invoiceState)
        }
        .alert(isPresented: Binding(
            get: { invoiceState.deleteTarget != nil },
            set: { if !$0 { invoiceState.deleteTarget = nil } }
        )) {
            Alert(
                title: Text("Delete Invoice"),
                message: Text("Delete invoice \"\(invoiceState.deleteTarget?.invoiceNumber ?? invoiceState.deleteTarget?.description ?? "")\"? This action cannot be undone."),
                primaryButton: .destructive(Text("Delete")) {
                    if let target = invoiceState.deleteTarget {
                        invoiceState.deleteInvoice(target)
                    }
                },
                secondaryButton: .cancel()
            )
        }
    }

    // MARK: - Tab Bar

    private var tabBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 0) {
                ForEach(InvoiceTab.allCases) { tab in
                    Button {
                        showRunTab = false
                        invoiceState.activeTab = tab
                        invoiceState.activeFilter = .all
                    } label: {
                        Text(tab.rawValue)
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(!showRunTab && invoiceState.activeTab == tab ? .goldDark : .secondary)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(
                                !showRunTab && invoiceState.activeTab == tab
                                    ? Color.gold.opacity(0.1) : Color.clear
                            )
                            .cornerRadius(6)
                    }
                    .buttonStyle(PlainButtonStyle())
                }

                // Run Approval tab (if approver)
                if invoiceState.isRunApprover {
                    Button {
                        showRunTab = true
                    } label: {
                        HStack(spacing: 4) {
                            Text("Payment Run Approval")
                                .font(.system(size: 12, weight: .semibold))
                            if invoiceState.pendingRuns.count > 0 {
                                Text("\(invoiceState.pendingRuns.count)")
                                    .font(.system(size: 10, weight: .bold))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 5)
                                    .padding(.vertical, 1)
                                    .background(Color.gold)
                                    .cornerRadius(8)
                            }
                        }
                        .foregroundColor(showRunTab ? .goldDark : .secondary)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(showRunTab ? Color.gold.opacity(0.1) : Color.clear)
                        .cornerRadius(6)
                    }
                    .buttonStyle(PlainButtonStyle())
                }

                Spacer()

                // Upload button
                Button { showDocPicker = true } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "arrow.up.doc")
                            .font(.system(size: 11))
                        Text("Upload")
                            .font(.system(size: 12, weight: .semibold))
                    }
                    .foregroundColor(.goldDark)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(Color.gold.opacity(0.1))
                    .cornerRadius(6)
                    .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.gold.opacity(0.3), lineWidth: 1))
                }
                .buttonStyle(PlainButtonStyle())
                .padding(.trailing, 4)
            }
            .padding(.horizontal, 16)
        }
        .padding(.vertical, 6)
        .background(Color.white)
        .overlay(
            Rectangle().frame(height: 1).foregroundColor(Color.borderColor),
            alignment: .bottom
        )
    }

    // MARK: - Quick Filters

    private var quickFilters: some View {
        let rows = invoiceState.buildRows()
        return HStack(spacing: 6) {
            Text("QUICK FILTERS")
                .font(.system(size: 9, weight: .bold))
                .foregroundColor(.gray)
                .tracking(1)

            ForEach(InvoiceQuickFilter.allCases, id: \.rawValue) { f in
                Button {
                    invoiceState.activeFilter = f
                } label: {
                    Text(f.rawValue)
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(invoiceState.activeFilter == f ? .white : .secondary)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(invoiceState.activeFilter == f ? Color.gold : Color.white)
                        .cornerRadius(6)
                        .overlay(
                            RoundedRectangle(cornerRadius: 6)
                                .stroke(invoiceState.activeFilter == f ? Color.gold : Color.borderColor, lineWidth: 1)
                        )
                }
                .buttonStyle(PlainButtonStyle())
            }

            Spacer()

            Text("\(rows.count) invoice\(rows.count == 1 ? "" : "s")")
                .font(.system(size: 11))
                .foregroundColor(.gray)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }

    // MARK: - Invoice List

    private var invoiceList: some View {
        let rows = invoiceState.buildRows()

        return Group {
            if invoiceState.isLoading {
                VStack(spacing: 8) {
                    ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .gold))
                    Text("Loading invoices...").font(.system(size: 13)).foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 40)
            } else if rows.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "doc.text")
                        .font(.system(size: 32))
                        .foregroundColor(.gray.opacity(0.4))
                    Text(emptyMessage)
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 40)
                .background(Color.white)
                .cornerRadius(12)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderColor, lineWidth: 1))
                .padding(.horizontal, 16)
            } else {
                ScrollView {
                    // Stats
                    invoiceStats(rows)

                    // Table
                    VStack(spacing: 0) {
                        // Header
                        HStack(spacing: 0) {
                            tableHeader("Invoice", width: nil)
                            tableHeader("Vendor", width: nil)
                            tableHeader("Gross", width: 80, alignment: .trailing)
                            tableHeader("Status", width: 100)
                            tableHeader("SLA", width: 80)
                            Spacer().frame(width: 44)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Color.bgRaised)

                        Divider()

                        // Rows
                        ForEach(rows) { row in
                            Button {
                                selectedRow = row
                                showDetail = true
                            } label: {
                                invoiceRowView(row)
                            }
                            .buttonStyle(PlainButtonStyle())
                            .opacity(invoiceState.deletingId == row.id ? 0.5 : 1)
                            .disabled(invoiceState.deletingId == row.id)

                            if row.id != rows.last?.id {
                                Divider().padding(.leading, 12)
                            }
                        }
                    }
                    .background(Color.white)
                    .cornerRadius(12)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderColor, lineWidth: 1))
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                }
            }
        }
    }

    private var emptyMessage: String {
        switch invoiceState.activeTab {
        case .my: return "You haven't uploaded any invoices yet"
        case .dept: return "No invoices found in your department"
        case .all: return "No invoices found"
        }
    }

    // MARK: - Stats

    private func invoiceStats(_ rows: [InvoiceRow]) -> some View {
        let pending = rows.filter { $0.raw.approvalStatus == "pending" }.count
        let approved = rows.filter { $0.raw.approvalStatus == "approved" }.count
        let total = rows.reduce(0.0) { $0 + $1.raw.grossAmount }

        return HStack(spacing: 10) {
            statCard("Total", "\(rows.count)", Color.primary)
            statCard("Pending", "\(pending)", Color.gold)
            statCard("Approved", "\(approved)", Color.green)
            statCard("Value", InvoiceState.formatCurrency(total), Color.gold)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }

    private func statCard(_ label: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 16, weight: .bold, design: .monospaced))
                .foregroundColor(color)
            Text(label)
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(Color.white)
        .cornerRadius(8)
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.borderColor, lineWidth: 1))
    }

    // MARK: - Table helpers

    private func tableHeader(_ text: String, width: CGFloat?, alignment: Alignment = .leading) -> some View {
        Text(text.uppercased())
            .font(.system(size: 9, weight: .bold))
            .foregroundColor(.gray)
            .tracking(0.5)
            .frame(width: width, alignment: alignment)
            .frame(maxWidth: width == nil ? .infinity : nil, alignment: alignment)
    }

    private func invoiceRowView(_ row: InvoiceRow) -> some View {
        HStack(spacing: 0) {
            // Invoice ref
            Text(row.ref)
                .font(.system(size: 11, weight: .bold, design: .monospaced))
                .foregroundColor(.primary)
                .frame(maxWidth: .infinity, alignment: .leading)

            // Vendor
            Text(row.supplier)
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(.primary)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)

            // Gross
            Text(row.gross)
                .font(.system(size: 12, weight: .bold, design: .monospaced))
                .frame(width: 80, alignment: .trailing)

            // Status
            BadgeView(text: row.approvalLabel, color: badgeColor(row.approvalColor))
                .frame(width: 100, alignment: .leading)

            // SLA
            BadgeView(
                text: row.sla.label,
                color: row.sla.isOverdue ? .rejectPink : (row.sla.isUrgent ? .orange : .blue)
            )
            .frame(width: 80, alignment: .leading)

            // Delete button
            Group {
                if invoiceState.deletingId == row.id {
                    ProgressView().progressViewStyle(CircularProgressViewStyle())
                        .scaleEffect(0.6)
                } else if row.raw.userId == invoiceState.userId &&
                          row.raw.approvalStatus == "pending" &&
                          row.raw.status != "approved" && row.raw.status != "rejected" {
                    Button {
                        invoiceState.deleteTarget = row.raw
                    } label: {
                        Text("Delete")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.red)
                            .cornerRadius(4)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .frame(width: 44, alignment: .trailing)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .contentShape(Rectangle())
    }

    private func badgeColor(_ name: String) -> Color {
        switch name {
        case "green": return .green
        case "red", "pink": return .rejectPink
        case "amber": return .orange
        default: return .gray
        }
    }
}

// MARK: - Document Picker (iOS)

#if canImport(UIKit)
import UIKit

struct InvoiceDocumentPicker: UIViewControllerRepresentable {
    @ObservedObject var invoiceState: InvoiceState

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let types = ["public.image", "com.adobe.pdf"]
        let picker = UIDocumentPickerViewController(documentTypes: types, in: .import)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(invoiceState: invoiceState)
    }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let invoiceState: InvoiceState

        init(invoiceState: InvoiceState) {
            self.invoiceState = invoiceState
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            guard url.startAccessingSecurityScopedResource() else { return }
            defer { url.stopAccessingSecurityScopedResource() }

            guard let data = try? Data(contentsOf: url) else { return }
            let fileName = url.lastPathComponent
            let ext = url.pathExtension.lowercased()
            let mimeType: String = {
                switch ext {
                case "pdf": return "application/pdf"
                case "jpg", "jpeg": return "image/jpeg"
                case "png": return "image/png"
                default: return "application/octet-stream"
                }
            }()

            DispatchQueue.main.async {
                self.invoiceState.uploadFileName = fileName
                self.invoiceState.uploadFileData = data
                self.invoiceState.uploadFileMimeType = mimeType
                self.invoiceState.showUploadPreview = true
                self.invoiceState.uploadFile(data, fileName: fileName, mimeType: mimeType)
            }
        }
    }
}
#endif
