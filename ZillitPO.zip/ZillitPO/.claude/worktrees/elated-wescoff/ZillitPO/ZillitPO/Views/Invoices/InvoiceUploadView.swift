//
//  InvoiceUploadView.swift
//  ZillitPO
//

import SwiftUI

// MARK: - Upload Preview Sheet

struct InvoiceUploadPreviewView: View {
    @ObservedObject var invoiceState: InvoiceState

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // File info header
                HStack {
                    Image(systemName: "doc.fill")
                        .foregroundColor(.gold)
                    Text(invoiceState.uploadFileName)
                        .font(.system(size: 13, weight: .semibold))
                        .lineLimit(1)
                    Spacer()
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color.bgRaised)

                Divider()

                // Status area
                VStack(spacing: 12) {
                    if invoiceState.uploading {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .gold))
                        Text("Extracting invoice data...")
                            .font(.system(size: 13))
                            .foregroundColor(.gold)
                    } else if invoiceState.uploadSubmitted {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 32))
                            .foregroundColor(.green)
                        Text("Invoice sent to accounts successfully")
                            .font(.system(size: 13))
                            .foregroundColor(.green)
                    } else if let error = invoiceState.uploadError {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 32))
                            .foregroundColor(.red)
                        Text(error)
                            .font(.system(size: 13))
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                    } else if invoiceState.uploadExtraction != nil {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 32))
                            .foregroundColor(.gold)
                        Text("Invoice data extracted — ready to send")
                            .font(.system(size: 13))
                            .foregroundColor(.secondary)

                        extractionSummary
                    } else {
                        Image(systemName: "doc.text.magnifyingglass")
                            .font(.system(size: 32))
                            .foregroundColor(.gray)
                        Text("Processing...")
                            .font(.system(size: 13))
                            .foregroundColor(.gray)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(24)

                Spacer()

                // Actions
                if !invoiceState.uploadSubmitted {
                    VStack(spacing: 8) {
                        Button {
                            invoiceState.showTypeSelect = true
                            invoiceState.invoiceType = nil
                        } label: {
                            Text("Send to Accounts")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(invoiceState.uploadExtraction != nil && !invoiceState.uploading ? Color.gold : Color.gray)
                                .cornerRadius(10)
                        }
                        .disabled(invoiceState.uploadExtraction == nil || invoiceState.uploading)
                    }
                    .padding(16)
                }
            }
            .navigationBarTitle("Upload Preview", displayMode: .inline)
            .navigationBarItems(trailing:
                Button("Close") { invoiceState.closeUpload() }
                    .foregroundColor(.gold)
            )
            .sheet(isPresented: $invoiceState.showTypeSelect) {
                InvoiceTypeSelectView(invoiceState: invoiceState)
            }
        }
    }

    private var extractionSummary: some View {
        VStack(alignment: .leading, spacing: 6) {
            if let ext = invoiceState.uploadExtraction {
                if let name = ext.supplier?.name, !name.isEmpty {
                    extractionRow("Supplier", name)
                }
                if let gross = ext.gross, !gross.isEmpty {
                    extractionRow("Amount", "£\(gross)")
                }
                if let po = ext.po_number, !po.isEmpty {
                    extractionRow("PO Number", po)
                }
                if let cur = ext.currency, !cur.isEmpty {
                    extractionRow("Currency", cur)
                }
            }
        }
        .padding(12)
        .background(Color.bgRaised)
        .cornerRadius(8)
        .frame(maxWidth: .infinity)
    }

    private func extractionRow(_ label: String, _ value: String) -> some View {
        HStack {
            Text(label).font(.system(size: 11, weight: .bold)).foregroundColor(.gray)
            Spacer()
            Text(value).font(.system(size: 12, weight: .semibold))
        }
    }
}

// MARK: - Invoice Type Selection

struct InvoiceTypeSelectView: View {
    @ObservedObject var invoiceState: InvoiceState
    @Environment(\.presentationMode) var presentationMode

    private let options: [(value: String, label: String, desc: String)] = [
        ("po", "Against Purchase Order", "Standard invoice matched to an existing PO"),
        ("cheque", "Cheque Request", "Payment via cheque — no PO required"),
        ("wire", "Wire Request", "Urgent wire transfer — requires override approval"),
    ]

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                VStack(alignment: .leading, spacing: 12) {
                    Text("How should this invoice be processed?")
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)

                    ForEach(options, id: \.value) { opt in
                        Button {
                            invoiceState.invoiceType = opt.value
                        } label: {
                            HStack(alignment: .top, spacing: 12) {
                                Image(systemName: invoiceState.invoiceType == opt.value ? "largecircle.fill.circle" : "circle")
                                    .font(.system(size: 18))
                                    .foregroundColor(invoiceState.invoiceType == opt.value ? .gold : .gray)

                                VStack(alignment: .leading, spacing: 2) {
                                    Text(opt.label)
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundColor(.primary)
                                    Text(opt.desc)
                                        .font(.system(size: 11))
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                            }
                            .padding(12)
                            .background(invoiceState.invoiceType == opt.value ? Color.gold.opacity(0.06) : Color.clear)
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(invoiceState.invoiceType == opt.value ? Color.gold.opacity(0.4) : Color.clear, lineWidth: 1)
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                .padding(16)

                Spacer()

                HStack(spacing: 12) {
                    Button("Cancel") {
                        invoiceState.showTypeSelect = false
                        invoiceState.invoiceType = nil
                        presentationMode.wrappedValue.dismiss()
                    }
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.borderColor))

                    Button {
                        invoiceState.submitUpload()
                        presentationMode.wrappedValue.dismiss()
                    } label: {
                        HStack(spacing: 4) {
                            if invoiceState.uploadSubmitting {
                                ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white)).scaleEffect(0.7)
                            }
                            Text("Confirm & Send")
                        }
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(invoiceState.invoiceType != nil && !invoiceState.uploadSubmitting ? Color.gold : Color.gray)
                        .cornerRadius(8)
                    }
                    .disabled(invoiceState.invoiceType == nil || invoiceState.uploadSubmitting)
                }
                .padding(16)
            }
            .navigationBarTitle("Send to Accounts", displayMode: .inline)
        }
    }
}
