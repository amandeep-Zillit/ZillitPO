//
//  PaymentRunApprovalView.swift
//  ZillitPO
//

import SwiftUI

// MARK: - Payment Run List (tab content)

struct PaymentRunListView: View {
    @ObservedObject var invoiceState: InvoiceState

    var body: some View {
        VStack(spacing: 0) {
            if invoiceState.pendingRunsLoading {
                VStack(spacing: 8) {
                    ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .gold))
                    Text("Loading payment runs...")
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 40)
            } else if invoiceState.pendingRuns.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "checkmark.circle")
                        .font(.system(size: 32))
                        .foregroundColor(.gray.opacity(0.4))
                    Text("No payment runs awaiting your approval")
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 40)
                .background(Color.white)
                .cornerRadius(12)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderColor, lineWidth: 1))
            } else {
                VStack(spacing: 0) {
                    ForEach(invoiceState.pendingRuns, id: \.id) { run in
                        Button {
                            invoiceState.openRunDetail(run.id)
                        } label: {
                            paymentRunRow(run)
                        }
                        .buttonStyle(PlainButtonStyle())

                        if run.id != invoiceState.pendingRuns.last?.id {
                            Divider()
                        }
                    }
                }
                .background(Color.white)
                .cornerRadius(12)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderColor, lineWidth: 1))
            }
        }
        .onAppear { invoiceState.fetchPendingRuns() }
        .sheet(isPresented: Binding(
            get: { invoiceState.selectedRunDetail != nil },
            set: { if !$0 { invoiceState.selectedRunDetail = nil; invoiceState.showRejectRun = false; invoiceState.rejectRunReason = "" } }
        )) {
            if let detail = invoiceState.selectedRunDetail {
                PaymentRunDetailSheet(detail: detail, invoiceState: invoiceState)
            }
        }
    }

    private func paymentRunRow(_ run: PaymentRun) -> some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(run.number)
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .foregroundColor(.primary)
                    Text(run.name)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.primary)
                        .lineLimit(1)
                }
                HStack(spacing: 6) {
                    BadgeView(text: run.payMethod.capitalized, color: .blue)
                    BadgeView(
                        text: "Pending (\(run.approval.count)/\(invoiceState.runAuth.count))",
                        color: .orange
                    )
                }
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 4) {
                Text(InvoiceState.formatCurrency(run.totalAmount))
                    .font(.system(size: 13, weight: .bold, design: .monospaced))
                Text("\(run.invoiceCount) invoices")
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }

            Image(systemName: "chevron.right")
                .font(.system(size: 11))
                .foregroundColor(.gray)
        }
        .padding(14)
        .contentShape(Rectangle())
    }
}

// MARK: - Payment Run Detail Sheet

struct PaymentRunDetailSheet: View {
    let detail: PaymentRunDetail
    @ObservedObject var invoiceState: InvoiceState
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                ScrollView {
                    VStack(spacing: 16) {
                        if invoiceState.runDetailLoading {
                            VStack(spacing: 8) {
                                ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .gold))
                                Text("Loading run details...")
                                    .font(.system(size: 13))
                                    .foregroundColor(.secondary)
                            }
                            .padding(.vertical, 40)
                        } else {
                            approvalChainSection
                            invoicesSection
                            creatorSection
                        }
                    }
                    .padding(16)
                }

                // Action buttons
                if detail.run.status == "pending" && !invoiceState.showRejectRun {
                    HStack(spacing: 12) {
                        Button("Reject") {
                            invoiceState.showRejectRun = true
                        }
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.borderColor))

                        Button {
                            invoiceState.approveRun()
                        } label: {
                            Text(invoiceState.approvingRunId == detail.run.id ? "Approving..." : "Approve")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(Color(red: 14/255, green: 15/255, blue: 18/255))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.gold)
                                .cornerRadius(8)
                        }
                        .disabled(invoiceState.approvingRunId == detail.run.id)
                        .opacity(invoiceState.approvingRunId == detail.run.id ? 0.6 : 1)
                    }
                    .padding(16)
                    .background(Color.bgRaised)
                }

                // Reject form
                if invoiceState.showRejectRun {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Reason for rejection")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(.secondary)

                        TextField("Provide a reason...", text: $invoiceState.rejectRunReason)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .font(.system(size: 13))

                        HStack(spacing: 12) {
                            Button("Cancel") {
                                invoiceState.showRejectRun = false
                                invoiceState.rejectRunReason = ""
                            }
                            .font(.system(size: 13))
                            .foregroundColor(.secondary)

                            Spacer()

                            Button {
                                invoiceState.rejectRun()
                            } label: {
                                Text(invoiceState.rejectingRun ? "Rejecting..." : "Reject run")
                                    .font(.system(size: 13, weight: .semibold))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 8)
                                    .background(invoiceState.rejectRunReason.trimmingCharacters(in: .whitespaces).isEmpty || invoiceState.rejectingRun ? Color.gray : Color.red)
                                    .cornerRadius(8)
                            }
                            .disabled(invoiceState.rejectRunReason.trimmingCharacters(in: .whitespaces).isEmpty || invoiceState.rejectingRun)
                        }
                    }
                    .padding(16)
                    .background(Color.bgRaised)
                }
            }
            .navigationBarTitle(detail.run.number.isEmpty ? "Loading..." : "\(detail.run.number) — \(detail.run.name)", displayMode: .inline)
            .navigationBarItems(trailing:
                Button("Close") {
                    invoiceState.selectedRunDetail = nil
                    invoiceState.showRejectRun = false
                    invoiceState.rejectRunReason = ""
                    presentationMode.wrappedValue.dismiss()
                }.foregroundColor(.gold)
            )
        }
    }

    // MARK: - Approval Chain

    private var approvalChainSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("APPROVAL CHAIN")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.gray)

            ForEach(invoiceState.runAuth.sorted(by: { $0.tier < $1.tier }), id: \.tier) { level in
                let approvalEntry = detail.run.approval.first { $0.tierNumber == level.tier }
                let isApproved = approvalEntry != nil
                let approvedByUser = approvalEntry?.userId.flatMap { UsersData.byId[$0] }

                HStack(spacing: 10) {
                    ZStack {
                        Circle()
                            .fill(isApproved ? Color.green.opacity(0.15) : Color.gold.opacity(0.15))
                            .frame(width: 32, height: 32)
                        if isApproved {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 14))
                                .foregroundColor(.green)
                        } else {
                            Text("\(level.tier)")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(.goldDark)
                        }
                    }

                    VStack(alignment: .leading, spacing: 1) {
                        Text("Level \(level.tier)")
                            .font(.system(size: 12, weight: .bold))
                        if isApproved {
                            Text(approvedByUser?.fullName ?? approvalEntry?.userId ?? "")
                                .font(.system(size: 11, weight: .medium))
                                .foregroundColor(.green)
                            if let desig = approvedByUser?.displayDesignation {
                                Text(desig).font(.system(size: 10)).foregroundColor(.green.opacity(0.7))
                            }
                        } else {
                            let names = level.user.compactMap { UsersData.byId[$0]?.fullName }
                            Text(names.isEmpty ? "No users assigned" : names.joined(separator: ", ") + " · Waiting")
                                .font(.system(size: 11))
                                .foregroundColor(.secondary)
                        }
                    }

                    Spacer()

                    if isApproved {
                        BadgeView(text: "Approved", color: .green)
                    } else {
                        BadgeView(text: "Pending", color: .orange)
                    }
                }
                .padding(10)
                .background(isApproved ? Color.green.opacity(0.04) : Color.gold.opacity(0.04))
                .cornerRadius(8)
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(isApproved ? Color.green.opacity(0.2) : Color.gold.opacity(0.2), lineWidth: 1))
            }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderColor, lineWidth: 1))
    }

    // MARK: - Invoices Table

    private var invoicesSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("INVOICES IN THIS RUN")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.gray)

            VStack(spacing: 0) {
                ForEach(detail.invoices, id: \.id) { inv in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(inv.invoiceNumber.isEmpty ? String(inv.id.prefix(8)) : inv.invoiceNumber)
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                            Text(inv.vendor.isEmpty ? "Unknown" : inv.vendor)
                                .font(.system(size: 11, weight: .semibold))
                                .foregroundColor(.secondary)
                            if let desc = inv.description, !desc.isEmpty {
                                Text(desc).font(.system(size: 10)).foregroundColor(.gray).lineLimit(1)
                            }
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 2) {
                            Text(InvoiceState.formatCurrency(inv.grossAmount, currency: inv.currency))
                                .font(.system(size: 12, weight: .bold, design: .monospaced))
                            Text(InvoiceState.formatDateOnly(inv.dueDate))
                                .font(.system(size: 10))
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)

                    if inv.id != detail.invoices.last?.id {
                        Divider().padding(.leading, 12)
                    }
                }
            }
            .background(Color.white)
            .cornerRadius(8)
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.borderColor, lineWidth: 1))

            // Summary
            HStack {
                Text("\(Set(detail.invoices.map { $0.vendorId ?? "" }).count) vendors · \(detail.invoices.count) invoices")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(.secondary)
                Spacer()
                Text(InvoiceState.formatCurrency(detail.invoices.reduce(0) { $0 + $1.grossAmount }))
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .foregroundColor(.blue)
            }
            .padding(.horizontal, 4)
        }
    }

    // MARK: - Creator

    private var creatorSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("CREATED BY").font(.system(size: 10, weight: .bold)).foregroundColor(.gray)
            if let creator = UsersData.byId[detail.run.createdBy] {
                Text(creator.fullName).font(.system(size: 13, weight: .semibold))
                Text(creator.displayDesignation).font(.system(size: 11)).foregroundColor(.secondary)
            } else {
                Text("System").font(.system(size: 13, weight: .semibold))
            }
            Text(InvoiceState.formatDateTime(detail.run.createdAt))
                .font(.system(size: 11)).foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.borderColor, lineWidth: 1))
    }
}
